/* Multiple Item Picker */
$('.selectpicker').selectpicker({
    style: 'btn-default'
  });