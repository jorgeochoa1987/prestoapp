<?php

$conexion = new mysqli("localhost", "root", "", "u465803286_prestoapp");

 if($conexion === false) { 
    echo 'Ha habido un error <br>'.mysqli_connect_error(); 
   } else {

//echo 'Conectado a la base de datos';
    
   }


?>